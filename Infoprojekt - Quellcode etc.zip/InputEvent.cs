namespace Info2021 {
    public enum InputEvent {
        Left, Right, Down, Up, Jump, Escape, Remove, NextThing, PreviousThing, Menu
    }
}