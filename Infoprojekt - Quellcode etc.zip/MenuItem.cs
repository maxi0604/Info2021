namespace Info2021 {
    public enum MenuItem {
        LevelSelect, LevelEdit, Exit
    }
}