namespace Info2021 {
    public enum GameState {
        Menu, Init, InLevel, Dead, BeatLevel, Pause, Edit, EditSelectionMenu, EditMenu, LevelSelect
    }
}