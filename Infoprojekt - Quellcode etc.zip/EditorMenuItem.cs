namespace Info2021 {
    public enum EditorMenuItem {
        Continue, PlaySave, Save, Backup, Reset, MainMenu
    }
}