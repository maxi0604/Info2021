namespace Info2021 {
    interface ILevelElement {
        void Add(Level level);
    }
}