namespace Info2021 {
    enum PauseMenuItem {
        Unpause, Retry, MainMenu
    }
}