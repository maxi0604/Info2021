namespace Info2021 {
    public enum LevelAddables {
        Tile, Cinematic, PlayerPos, CameraPos
    }
}